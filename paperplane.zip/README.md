# paperplane :airplane:
paperplane is a program that allows you to set up a portable minecraft server in minutes
  
paperplane currently uses [Tuinity](https://github.com/Spottedleaf/Tuinity), a fork of [Paper](https://github.com/PaperMC/Paper), a fork of [Spigot](https://github.com/SpigotMC/Spigot-Server), a fork of [Bukkit](https://github.com/Bukkit/Bukkit)
